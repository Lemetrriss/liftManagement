package logic.DAO;

import logic.POJO.Lift;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class LiftImpl implements Lift {
    private String direction;
    private int location;
    private final int capacity;
    private int fill;
    private List<Boolean> rout;
    private LinkedList<Boolean> callsFromFlors;
    private List<HumanImpl> passengers = new LinkedList<>();
    private static LiftImpl lift;

    private LiftImpl(int capacity, int fill, int location, List<Boolean> rout) {
        this.capacity = capacity;
        this.fill = fill;
        this.location = location;
        this.rout = rout;
    }

    private static void createLift(int numberOfFloors){
        List<Boolean> rout = new ArrayList<>();
        LinkedList<Boolean> calls = new LinkedList<>();
        for (int i = 0; i <= numberOfFloors; i++) {
            rout.add(false);
            calls.add(false);
        }

        lift = new LiftImpl(5, 0, 1, rout);
        lift.setCallsFromFloors(calls);
    }

//    public static void main(String[] args) {
//        createLift(13);
//        System.out.println(lift);
//        System.out.println(lift.getRout().size());
//    }

    public static LiftImpl getLift(int numberOfFloors){
        if (lift==null)
            createLift(numberOfFloors);
        return lift;
    }

    public List<HumanImpl> getPassengers() { return passengers; }

    public List<Boolean> getCallsFromFloors() { return callsFromFlors; }

    public void setCallsFromFloors(LinkedList<Boolean> callsFromFlors) { this.callsFromFlors = callsFromFlors; }

    public void setCalls(int n, boolean b) { callsFromFlors.set(n, b); }

    public List<Boolean> getRout() {
        return rout;
    }

    public void setRout(int n, boolean b) { rout.set(n, b); }

    public int getCapacity() {
        return capacity;
    }

    public int getFill() { return fill; }

    public void setFill(int fill) {
        this.fill = fill;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) { this.location = location; }

    public String getDirection() { return direction; }

    public void setDirection(String direction) { this.direction = direction; }

    public void moveEmpty(int floor){
        location = floor;
        rout.set(floor, false);
    }

    public void move(){
        if (isUp()){
            for (int i=location+1; i < rout.size(); i++){
                if (rout.get(i)) {
                    location = i;
                    rout.set(i,false);
                    callsFromFlors.set(i, false);
                    break;
                }
                if (!isFull()){
                    if (callsFromFlors.get(i)){
                        location = i;
                        callsFromFlors.set(i, false);
                        break;
                    }
                }
            }
        } else if (isDown()){
            for (int i=location-1; i >= 1; i--){
                if (rout.get(i)) {
                    location = i;
                    rout.set(i, false);
                    break;
                }
                if (!isFull()){
                    if (callsFromFlors.get(i)){
                        location = i;
                        callsFromFlors.set(i, false);
                        break;
                    }
                }
            }
        }
    }

    boolean isUp(){ return direction.trim().equalsIgnoreCase("up"); }

    boolean isDown(){ return direction.trim().equalsIgnoreCase("down"); }

    public boolean isFull(){ return capacity-fill == 0;}

    public boolean isEmptyLift(){ return fill == 0; }

    public void loadPassenger(HumanImpl human){
        passengers.add(human);
        fill++;
    }

    @Override
    public String toString() {
        return "LiftImpl{" +
                "direction='" + direction + '\'' +
                ", location=" + location +
                ", capacity=" + capacity +
                ", fill=" + fill +
                ", rout=" + rout +
                ", passengers=" + passengers +
                '}';
    }
}
