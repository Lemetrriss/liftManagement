package logic.DAO;

import logic.POJO.Human;

public class HumanImpl implements Human {
    private int destinationFloor;
    private int humanLocation;

    public HumanImpl(int destinationFloor, int humanLocation) {
        this.destinationFloor = destinationFloor;
        this.humanLocation = humanLocation;
    }

    public void setDestinationFloor(int destinationFloor) {
        this.destinationFloor = destinationFloor;
    }

    public int getDestinationFloor() {
        return destinationFloor;
    }

    public int getHumanLocation() {
        return humanLocation;
    }

    public void setHumanLocation(int humanLocation) {
        this.humanLocation = humanLocation;
    }

    @Override
    public String toString() {
        return "HumanImpl{" +
                "destinationFloor=" + destinationFloor +
                '}';
    }
}
