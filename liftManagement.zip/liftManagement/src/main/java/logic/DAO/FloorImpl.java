package logic.DAO;

import logic.Main;
import logic.POJO.Floor;
import java.util.LinkedList;
import java.util.Random;

public class FloorImpl implements Floor {
    Random r = new Random(77);
    private final int floorNumber;
    private int numberOfHumans;
    private LinkedList<HumanImpl> listOfHumans = new LinkedList<>();

    public FloorImpl(int floorNumber, int totalFloors) {
        this.floorNumber = floorNumber;
        numberOfHumans = r.nextInt(9)+1;
        for (int i=1; i<=numberOfHumans; i++){
            int n = r.nextInt(Main.numberOfFloors) + 1;
            if (n == floorNumber && n < totalFloors){
                n++;
            } else if (n == floorNumber && n == totalFloors){
                n = 1;
            }
            listOfHumans.add(new HumanImpl(n, floorNumber));
        }
    }

    public int getFloorNumber(){ return floorNumber; }

    public int getNumberOfHumans(){ return numberOfHumans; }

    public void setNumberOfHumans(int numberOfHumans){ this.numberOfHumans = numberOfHumans; }

    public LinkedList<HumanImpl> getListOfHumans() { return listOfHumans; }

    public void setListOfHumans(LinkedList<HumanImpl> listOfHumans) { this.listOfHumans = listOfHumans; }

//    public boolean callLift(LiftImpl lift){
//        if (!isEmptyFloor()) {
//            for (HumanImpl listOfHuman : listOfHumans) {
//
//            }
//        }
//    }

    public void callUp() {

    }

    public void callDown() {

    }

    public boolean isEmptyFloor(){ return numberOfHumans == 0; }

    public String direction(){
        int upper, lower;
        {
            upper = 0;
            lower = 0;
        }
        for (HumanImpl human : listOfHumans) {
            if (human.getDestinationFloor()>floorNumber) { upper++; }
            else { lower++; }
        }
        return upper>lower ? "up" : "down";
    }

    public HumanImpl goToLift(LiftImpl lift){
//        lift.getLocation() < Main.numberOfFloors
        if (lift.isUp()){
            for (int i=0; i< listOfHumans.size(); i++) {
                if (listOfHumans.get(i).getDestinationFloor() > lift.getLocation()){
                    numberOfHumans--;

                    return listOfHumans.remove(i);
                }
            }
        } else if (lift.isDown()){
            for (int i=0; i< listOfHumans.size(); i++) {
                if (listOfHumans.get(i).getDestinationFloor() < lift.getLocation()){
                    numberOfHumans--;
                    return listOfHumans.remove(i);
                }
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "FloorImpl{" +
                "floorNumber=" + floorNumber +
                ", numberOfHumans=" + numberOfHumans +
                ", Humans=" + listOfHumans +
                '}';
    }
}
