package logic.POJO;

public interface Human {

}
