package logic.POJO;

public interface Lift {

}
