package logic.POJO;

public interface Floor {
    void callUp();
    void callDown();
}
