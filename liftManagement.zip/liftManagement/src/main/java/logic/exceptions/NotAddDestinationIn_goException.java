package logic.exceptions;

public class NotAddDestinationIn_goException extends Exception {

    public NotAddDestinationIn_goException(String s) {
    }

    public NotAddDestinationIn_goException() {
    }

    public NotAddDestinationIn_goException(String message, Throwable cause) {
        super(message, cause);
    }
}
