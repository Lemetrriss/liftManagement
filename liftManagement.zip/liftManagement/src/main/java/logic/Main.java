package logic;

import logic.logic.Logic;

public class Main {

    public static void main(String[] args) {
        new Logic().go();
    }
}