package logic;

import logic.DAO.FloorImpl;
import logic.DAO.HumanImpl;
import logic.DAO.LiftImpl;

import java.util.*;

public class Main {

    public final static int numberOfFloors = new Random(47).nextInt(15) + 5; //13

    private List<FloorImpl> createFloors() {
        List<FloorImpl> list = new ArrayList<>();
        for (int i = 0; i <= numberOfFloors; i++) {     // 0 - 12
            list.add(new FloorImpl(i, numberOfFloors)); // 13
        }
        return list;
    }

//    private boolean isFull(LiftImpl l){
//        return l.getCapacity()-l.getFill() == 0;
//    }

    private List<List<HumanImpl>> liftLoad(LiftImpl l, FloorImpl f){
        List<List<HumanImpl>> liftFloorHumans = new ArrayList<>();
        List<HumanImpl> inLift = l.getPassengers();
        List<HumanImpl> onFloor = f.getListOfHumans();
        while (!(f.getNumberOfHumans()==0 || l.isFull())){
            HumanImpl human = f.goToLift(l); //подбираем этажа попутного пассажира и уменьшаем количество чел на этаже на 1
            if (human==null) { break; } //проверяем, вдруг люди на этаже есть, но подбирать некого
            l.loadPassenger(human); //добавляем чела с этажа в список пассажиров лифта и увеличиваем количество пассажиров лифта на 1
            l.setRout(human.getDestinationFloor(), true);
        }

        liftFloorHumans.add(inLift);
        liftFloorHumans.add(onFloor);
        return liftFloorHumans;
    }

    private void liftUnload(LiftImpl l, FloorImpl f){
        Iterator<HumanImpl> iterator = l.getPassengers().iterator();
        while (iterator.hasNext()){
            HumanImpl next = iterator.next();
            if (next.getDestinationFloor()==f.getFloorNumber()){
                iterator.remove();
                l.setFill(l.getFill()-1);
            }
        }
        l.setRout(f.getFloorNumber(), false);
        l.setCalls(f.getFloorNumber(), false);
    }

    public static void main(String[] args) {
        Main m = new Main();
        List<FloorImpl> floors = m.createFloors();
        System.out.println(numberOfFloors);
        for (FloorImpl floor : floors) {
            System.out.println(floor);
        }

        LiftImpl lift = LiftImpl.getLift(numberOfFloors);

//        for (FloorImpl floor : floors) {
        do {
            FloorImpl floor = floors.get(lift.getLocation());
            m.liftUnload(lift, floor);
            List<List<HumanImpl>> lists;
            if (lift.isEmptyLift()){
                lift.setDirection(null);
                if (floor.isEmptyFloor()){
                    int floorNumber = m.getFloorNumber(floors, floor, lift);

                    if (floorNumber==0){
                        System.out.println("There are no more passengers!");
                        return;
                    }
                    lift.setRout(floorNumber, true);
                    lift.moveEmpty(floorNumber);
                }
                if (lift.getLocation()==numberOfFloors){
                    lift.setDirection("down");
                    //
                    for (int fdwn=numberOfFloors-1; fdwn>1; fdwn--) {
                        FloorImpl floor_dwn = floors.get(fdwn);
                        LinkedList<HumanImpl> listOfHumans = floor_dwn.getListOfHumans();
                        for (HumanImpl humanDown : listOfHumans) {
                            if (humanDown.getDestinationFloor()<humanDown.getHumanLocation()){
                                lift.getCallsFromFloors().set(floor_dwn.getFloorNumber(), true);
                            }
                        }
                    }
                } else if(lift.getLocation()==1){
                    lift.setDirection("up");
                    //
                    for (int fup=2; fup<numberOfFloors; fup++) {
                        FloorImpl floor_up = floors.get(fup);
                        LinkedList<HumanImpl> listOfHumans = floor_up.getListOfHumans();
                        for (HumanImpl humanDown : listOfHumans) {
                            if (humanDown.getDestinationFloor()>humanDown.getHumanLocation()){
                                lift.getCallsFromFloors().set(floor_up.getFloorNumber(), true);
                            }
                        }
                    }
                } else{
                    lift.setDirection(floor.direction());
                    //
                    int location = lift.getLocation();
                    if (lift.getDirection().equalsIgnoreCase("down")){
                        for (int middle_f_dwn=location-1; middle_f_dwn>1; middle_f_dwn--) {
                            FloorImpl floor_dwn = floors.get(middle_f_dwn);
                            LinkedList<HumanImpl> listOfHumans = floor_dwn.getListOfHumans();
                            for (HumanImpl humanDown : listOfHumans) {
                                if (humanDown.getDestinationFloor()<humanDown.getHumanLocation()){
                                    lift.getCallsFromFloors().set(floor_dwn.getFloorNumber(), true);
                                }
                            }
                        }
                    } else {
                        for (int middle_f_up=location+1; middle_f_up<numberOfFloors; middle_f_up++) {
                            FloorImpl floor_up = floors.get(middle_f_up);
                            LinkedList<HumanImpl> listOfHumans = floor_up.getListOfHumans();
                            for (HumanImpl humanDown : listOfHumans) {
                                if (humanDown.getDestinationFloor()>humanDown.getHumanLocation()){
                                    lift.getCallsFromFloors().set(floor_up.getFloorNumber(), true);
                                }
                            }
                        }
                    }
                }
            }
            lists = m.liftLoad(lift, floor);

            System.out.println("Floor " + floor.getFloorNumber() + ":");
            System.out.print("in lift: |");
            for (HumanImpl human : lists.get(0)) {
                System.out.print(human.getDestinationFloor()+",");
            }
            System.out.print("| at floor: ");
            for (HumanImpl human: lists.get(1)) {
                System.out.print(human.getDestinationFloor()+",");
            }
            System.out.print("| rout of lift: ");
            for (int i = 1; i<lift.getRout().size(); i++) {
                if (lift.getRout().get(i)) {
                    System.out.print(i+", ");
                }
            }
            System.out.println();
            lift.move();
        } while (m.haveWork(lift, floors));
    }

    private boolean haveWork(LiftImpl lift, List<FloorImpl> floors){
        boolean b = false;
//        if(!(lift.isEmptyLift() && lift.getRout().contains(true) && lift.getCallsFromFloors().contains(true))) {
//            b = true;
//        }
        int count = 0;
        for (FloorImpl floor : floors) {
            count += floor.getNumberOfHumans();
        }
        if (count!=0){
            b = true;
        }
        return b;
    }

    private int getFloorNumber(List<FloorImpl> floors, FloorImpl floor, LiftImpl lift) {
        int currentFloor = floor.getFloorNumber();
        int floorNumber = 0;
        List<Boolean> callsFromFloors = lift.getCallsFromFloors();
        if(callsFromFloors.contains(true)){
            floorNumber = callsFromFloors.indexOf(true);
            callsFromFloors.set(floorNumber, false);
        } else {
            int floorHuman = 0;
            for (FloorImpl f : floors) {
                int temp = f.getNumberOfHumans();
                if (temp>floorHuman) {
                    floorHuman = temp;
                    floorNumber = f.getFloorNumber();
                }
            }
        }
//            if (currentFloor==numberOfFloors){
//            for (int i=currentFloor-1; i>=1; i--){
//                int next = floors.get(i).getNumberOfHumans();
//                if (next>0) {
//                    floorNumber = next;
//                    break;
//                }
//            }
//        } else if(currentFloor==1){
//            for (int i=2; i<=numberOfFloors; i++){
//                int next = floors.get(i).getNumberOfHumans();
//                if (next>0) {
//                    floorNumber = next;
//                    break;
//                }
//            }
//        } else {
//            for (int i=currentFloor+1; i<=numberOfFloors; i++){
//                int next = floors.get(i).getNumberOfHumans();
//                if (next>0) {
//                    floorNumber = next;
//                    break;
//                }
//            }
//            if (floorNumber==0){
//                for (int i=currentFloor-1; i>=1; i--){
//                    int next = floors.get(i).getNumberOfHumans();
//                    if (next>0) {
//                        floorNumber = next;
//                        break;
//                    }
//                }
//            }
//        }
        return floorNumber;
    }
}