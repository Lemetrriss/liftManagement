package logic.constants;

public class Constants {
    public static int timeToWait = 500;
}
